# 🔒 Discord Lua Obfuscator Bot

بوت ديسكورد يشفر سكربتات Lua باستخدام MoonSec

---

## ⚙️ طريقة الرفع على Railway

### 1. إنشاء بوت ديسكورد
1. روح على [Discord Developer Portal](https://discord.com/developers/applications)
2. اضغط **New Application** وسمّيه
3. روح لـ **Bot** → اضغط **Add Bot**
4. اضغط **Reset Token** وانسخ التوكن
5. فعّل **Message Content Intent** و **Server Members Intent**
6. روح لـ **OAuth2 → URL Generator**:
   - Scopes: `bot` + `applications.commands`
   - Bot Permissions: `Send Messages` + `Use Slash Commands` + `Attach Files`
7. افتح الرابط وأضف البوت لسيرفرك

### 2. رفع الكود على GitHub
```bash
git init
git add .
git commit -m "init"
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```

### 3. نشر على Railway
1. روح على [railway.app](https://railway.app) وسجل دخول
2. اضغط **New Project → Deploy from GitHub Repo**
3. اختر الريبو
4. روح لـ **Variables** وأضف:

| Variable | Value |
|----------|-------|
| `DISCORD_TOKEN` | توكن البوت من Developer Portal |
| `CLIENT_ID` | الـ Application ID من Developer Portal |

5. اضغط **Deploy** ✅

---

## 🤖 الأوامر

| الأمر | الوصف |
|-------|-------|
| `/set` | يحدد الروم الحالي كروم التشفير (للادمن فقط) |
| `/obf file:ملف.lua` | يشفر ملف لوا مرفوع |
| `/obf code:كودك` | يشفر كود لوا مكتوب مباشرة |

---

## 📝 ملاحظات
- البوت يحمل MoonSec تلقائياً من GitHub عند أول تشغيل
- ملف `allowed_channels.json` يحفظ الروم المحدد لكل سيرفر
- يجب تشغيل `/set` مرة واحدة فقط في كل سيرفر
